# RUS Receipt App v2 - Supabase Central Database

เว็บระบบออกใบเสร็จรับเงินสำหรับมหาวิทยาลัยเทคโนโลยีราชมงคลสุวรรณภูมิ

## จุดสำคัญ

- ใช้ฐานข้อมูลกลาง Supabase
- User ไม่ต้องกรอก email
- User Login ด้วยรหัส 4 หลักที่ Admin สร้างเท่านั้น
- Admin Login ด้วย username/password
- ออกใบเสร็จต้นฉบับ/สำเนา
- เล่มใบเสร็จล็อกเลขด้วย RPC เพื่อช่วยป้องกันเลขซ้ำ
- รายงานแยกรายการย่อยต่อแถว และ Export CSV

## วิธีติดตั้ง

1. สร้าง Supabase Project
2. เปิด Supabase SQL Editor
3. Copy โค้ดจาก `supabase/schema-v2.sql` ไปรันทั้งหมด
4. เปิดเว็บ `index.html`
5. ใส่ Supabase URL และ Public anon key ในหน้าแรก
6. Login Admin:
   - Username: `admin`
   - Password: `9999`
7. เข้าเมนูผู้ใช้งาน เพื่อสร้างรหัส User 4 หลัก

## GitHub Pages

อัปโหลดไฟล์ทั้งหมดนี้ขึ้น root ของ repo แล้วเปิด GitHub Pages แบบ Deploy from branch ได้ทันที

## ข้อควรทราบด้านความปลอดภัย

เวอร์ชันนี้ทำให้ Static Website ใช้ฐานกลางได้จริง และ User ไม่ต้องใช้ email แต่เพราะเป็นเว็บ static จึงยังไม่ใช่ระบบรักษาความปลอดภัยระดับ production เต็มรูปแบบสำหรับงานการเงิน หากใช้งานจริงในองค์กร ควรเพิ่ม Supabase Edge Functions หรือ Backend เพื่อควบคุมสิทธิ์ Admin ให้เข้มงวดขึ้น


## ตั้งค่า Supabase ที่ใส่ให้แล้ว

Project URL: `https://hmpjgnshmzhbuaxnkmcz.supabase.co`

Public anon key ถูกใส่ไว้ใน `app.js` แล้ว ดังนั้นหลังรัน `supabase/schema-v2.sql` และเปิด GitHub Pages เว็บจะเชื่อมฐานกลางได้ทันที

Admin เริ่มต้น: `admin` / `9999`

User ไม่ต้องใช้อีเมล ให้ Admin สร้างรหัสผู้ใช้งาน 4 หลักในเมนูผู้ใช้งานก่อน

> หมายเหตุ: public anon key ใช้กับเว็บหน้า public ได้ แต่ห้ามใส่ `service_role key` ลง GitHub หรือส่งในแชต
