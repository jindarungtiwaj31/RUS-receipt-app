-- RMUTSB Receipt App - Supabase central database
-- Run once in Supabase SQL Editor before using the website.
-- Login model: Admin uses username/password. User uses only a 4-digit code created by Admin. No email is required for User.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key default gen_random_uuid(),
  role text not null check (role in ('admin','user')),
  username text unique,
  staff_code text unique,
  display_name text not null,
  password_hash text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint user_code_4_digits check (staff_code is null or staff_code ~ '^\d{4}$')
);

create table if not exists public.receipt_books (
  id uuid primary key default gen_random_uuid(),
  book_no text not null unique,
  start_no int not null default 1,
  end_no int not null default 500,
  latest_no int not null default 0,
  active boolean not null default false,
  closed boolean not null default false,
  created_at timestamptz not null default now(),
  constraint receipt_book_range check (end_no >= start_no and end_no - start_no + 1 <= 500)
);

create table if not exists public.system_options (
  id uuid primary key default gen_random_uuid(),
  category text not null check (category in ('title','payment_item','project','payer_bank')),
  label text not null,
  active boolean not null default true,
  sort_order int not null default 100,
  created_at timestamptz not null default now(),
  unique(category, label)
);

create table if not exists public.bank_accounts (
  id uuid primary key default gen_random_uuid(),
  bank_name text not null,
  account_name text not null,
  account_no text not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.receipts (
  id uuid primary key default gen_random_uuid(),
  book_id uuid references public.receipt_books(id),
  book_no text not null,
  receipt_no int not null,
  issuer_id uuid references public.profiles(id),
  issuer_code text,
  issuer_name text not null,
  payer_type text not null,
  payer_name text not null,
  detail1 text,
  detail2 text,
  payment_method text not null,
  transfer_date date,
  payer_bank text,
  bank_account_id uuid references public.bank_accounts(id),
  project_name text,
  more_detail text,
  total_amount numeric(12,2) not null default 0,
  status text not null default 'normal' check (status in ('normal','cancelled')),
  cancel_reason text,
  cancelled_at timestamptz,
  created_at timestamptz not null default now(),
  unique(book_no, receipt_no)
);

create table if not exists public.receipt_items (
  id uuid primary key default gen_random_uuid(),
  receipt_id uuid not null references public.receipts(id) on delete cascade,
  item_name text not null,
  amount numeric(12,2) not null default 0,
  created_at timestamptz not null default now()
);

create or replace function public.touch_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_touch_updated_at on public.profiles;
create trigger profiles_touch_updated_at
before update on public.profiles
for each row execute function public.touch_updated_at();

insert into public.profiles (role, username, display_name, password_hash, active)
values ('admin', 'admin', 'ผู้ดูแลระบบ', crypt('9999', gen_salt('bf')), true)
on conflict (username) do update
set role = excluded.role,
    display_name = excluded.display_name,
    password_hash = coalesce(public.profiles.password_hash, excluded.password_hash),
    active = true;

insert into public.receipt_books (book_no, start_no, end_no, latest_no, active, closed)
values ('2569-001', 1, 500, 0, true, false)
on conflict (book_no) do nothing;

insert into public.system_options (category, label, sort_order) values
('title','นาย',1),('title','นาง',2),('title','นางสาว',3),('title','ดร.',4),('title','อื่นๆ',99),
('payment_item','ค่าลงทะเบียน',1),('payment_item','ค่าธรรมเนียมธนาคาร',2),('payment_item','ค่าบำรุงการศึกษา',3),
('project','ไม่ระบุโครงการ',1),('project','โครงการบริการวิชาการ',2),
('payer_bank','ธนาคารกรุงไทย',1),('payer_bank','ธนาคารไทยพาณิชย์',2),('payer_bank','ธนาคารกสิกรไทย',3),('payer_bank','ธนาคารกรุงเทพ',4)
on conflict (category, label) do nothing;

insert into public.bank_accounts (bank_name, account_name, account_no, active)
select 'ธนาคารกรุงไทย', 'มหาวิทยาลัยเทคโนโลยีราชมงคลสุวรรณภูมิ', '000-0-00000-0', true
where not exists (select 1 from public.bank_accounts);

create or replace function public.admin_login(p_username text, p_password text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_profile profiles;
begin
  select * into v_profile
  from public.profiles
  where username = p_username and role = 'admin' and active = true
  limit 1;

  if v_profile.id is null or v_profile.password_hash is null or v_profile.password_hash <> crypt(p_password, v_profile.password_hash) then
    return jsonb_build_object('ok', false, 'message', 'Username หรือ Password ไม่ถูกต้อง');
  end if;

  return jsonb_build_object('ok', true, 'profile', jsonb_build_object(
    'id', v_profile.id,
    'role', v_profile.role,
    'username', v_profile.username,
    'display_name', v_profile.display_name
  ));
end;
$$;

create or replace function public.user_login(p_code text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_profile profiles;
begin
  if p_code !~ '^\d{4}$' then
    return jsonb_build_object('ok', false, 'message', 'กรุณากรอกรหัส 4 หลัก');
  end if;

  select * into v_profile
  from public.profiles
  where staff_code = p_code and role = 'user'
  limit 1;

  if v_profile.id is null then
    return jsonb_build_object('ok', false, 'message', 'ไม่พบรหัสนี้ กรุณาให้ Admin สร้าง User ก่อน');
  end if;

  if not v_profile.active then
    return jsonb_build_object('ok', false, 'message', 'User นี้ถูกปิดใช้งาน');
  end if;

  return jsonb_build_object('ok', true, 'profile', jsonb_build_object(
    'id', v_profile.id,
    'role', v_profile.role,
    'staff_code', v_profile.staff_code,
    'display_name', v_profile.display_name
  ));
end;
$$;

create or replace function public.issue_receipt(p_payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_book receipt_books;
  v_next int;
  v_receipt_id uuid;
  v_item jsonb;
  v_total numeric(12,2) := 0;
  v_issuer profiles;
begin
  select * into v_issuer
  from public.profiles
  where id = (p_payload->>'issuer_id')::uuid and active = true
  limit 1;

  if v_issuer.id is null then
    return jsonb_build_object('ok', false, 'message', 'User ถูกปิดใช้งานหรือไม่มีสิทธิ์ออกใบเสร็จ');
  end if;

  select * into v_book
  from public.receipt_books
  where active = true and closed = false
  order by created_at
  limit 1
  for update;

  if v_book.id is null then
    return jsonb_build_object('ok', false, 'message', 'ยังไม่มีเล่มใบเสร็จที่เปิดใช้งาน');
  end if;

  v_next := greatest(v_book.start_no, v_book.latest_no + 1);
  if v_next > v_book.end_no then
    return jsonb_build_object('ok', false, 'message', 'เลขในเล่มนี้ครบแล้ว กรุณาเปิดเล่มใหม่');
  end if;

  for v_item in select * from jsonb_array_elements(coalesce(p_payload->'items', '[]'::jsonb)) loop
    v_total := v_total + coalesce((v_item->>'amount')::numeric, 0);
  end loop;

  if v_total <= 0 then
    return jsonb_build_object('ok', false, 'message', 'ยอดเงินต้องมากกว่า 0');
  end if;

  update public.receipt_books set latest_no = v_next where id = v_book.id;

  insert into public.receipts (
    book_id, book_no, receipt_no,
    issuer_id, issuer_code, issuer_name,
    payer_type, payer_name, detail1, detail2,
    payment_method, transfer_date, payer_bank, bank_account_id,
    project_name, more_detail, total_amount, status
  ) values (
    v_book.id, v_book.book_no, v_next,
    v_issuer.id, coalesce(v_issuer.staff_code, v_issuer.username), v_issuer.display_name,
    p_payload->>'payer_type', p_payload->>'payer_name', p_payload->>'detail1', p_payload->>'detail2',
    p_payload->>'payment_method', nullif(p_payload->>'transfer_date','')::date, p_payload->>'payer_bank', nullif(p_payload->>'bank_account_id','')::uuid,
    p_payload->>'project_name', p_payload->>'more_detail', v_total, 'normal'
  ) returning id into v_receipt_id;

  for v_item in select * from jsonb_array_elements(coalesce(p_payload->'items', '[]'::jsonb)) loop
    if coalesce((v_item->>'amount')::numeric, 0) > 0 then
      insert into public.receipt_items (receipt_id, item_name, amount)
      values (v_receipt_id, v_item->>'item', (v_item->>'amount')::numeric);
    end if;
  end loop;

  return jsonb_build_object('ok', true, 'receipt', jsonb_build_object('id', v_receipt_id, 'book_no', v_book.book_no, 'receipt_no', v_next));
end;
$$;

create or replace function public.cancel_receipt(p_receipt_id uuid, p_reason text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if coalesce(trim(p_reason), '') = '' then
    return jsonb_build_object('ok', false, 'message', 'กรุณาระบุหมายเหตุการยกเลิก');
  end if;

  update public.receipts
  set status = 'cancelled', cancel_reason = p_reason, cancelled_at = now()
  where id = p_receipt_id and status <> 'cancelled';

  if not found then
    return jsonb_build_object('ok', false, 'message', 'ไม่พบใบเสร็จ หรือใบเสร็จถูกยกเลิกแล้ว');
  end if;

  return jsonb_build_object('ok', true);
end;
$$;

alter table public.profiles enable row level security;
alter table public.receipt_books enable row level security;
alter table public.system_options enable row level security;
alter table public.bank_accounts enable row level security;
alter table public.receipts enable row level security;
alter table public.receipt_items enable row level security;

do $$
declare
  t text;
begin
  foreach t in array array['profiles','receipt_books','system_options','bank_accounts','receipts','receipt_items'] loop
    execute format('drop policy if exists "anon read %I" on public.%I', t, t);
    execute format('drop policy if exists "anon write %I" on public.%I', t, t);
    execute format('create policy "anon read %I" on public.%I for select to anon, authenticated using (true)', t, t);
    execute format('create policy "anon write %I" on public.%I for all to anon, authenticated using (true) with check (true)', t, t);
  end loop;
end $$;

grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on public.profiles to anon, authenticated;
grant select, insert, update, delete on public.receipt_books to anon, authenticated;
grant select, insert, update, delete on public.system_options to anon, authenticated;
grant select, insert, update, delete on public.bank_accounts to anon, authenticated;
grant select, insert, update, delete on public.receipts to anon, authenticated;
grant select, insert, update, delete on public.receipt_items to anon, authenticated;
grant execute on function public.admin_login(text,text) to anon, authenticated;
grant execute on function public.user_login(text) to anon, authenticated;
grant execute on function public.issue_receipt(jsonb) to anon, authenticated;
grant execute on function public.cancel_receipt(uuid,text) to anon, authenticated;

-- Production security note:
-- This version supports no-email User login for a static GitHub Pages app.
-- For stricter security, move Admin actions to Supabase Edge Functions or a server backend.
