const APP = (() => {
  const LS_CONFIG = 'rus_receipt_supabase_config_v1';
  const state = {
    sb: null,
    session: null,
    view: 'dashboard',
    data: { users: [], books: [], options: [], banks: [], receipts: [], items: [] },
    receiptLines: []
  };

  const $ = (id) => document.getElementById(id);
  const money = (n) => Number(n || 0).toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const dt = (v) => new Date(v).toLocaleString('th-TH', { dateStyle: 'short', timeStyle: 'short' });
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
  const uid = () => 'tmp_' + Math.random().toString(36).slice(2);

  function getConfig() {
    const d = { url: 'https://hmpjgnshmzhbuaxnkmcz.supabase.co', anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhtcGpnbnNobXpoYnVheG5rbWN6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODI4Mzg4MjksImV4cCI6MjA5ODQxNDgyOX0.KQZNBiIaIg9_2p4OkOO2OBWIvWnB7NRODn2kcfaKpxQ' };
    try { return Object.assign(d, JSON.parse(localStorage.getItem(LS_CONFIG) || '{}')); } catch { return d; }
  }
  function setConfig(cfg) {
    localStorage.setItem(LS_CONFIG, JSON.stringify({ url: cfg.url.trim(), anonKey: cfg.anonKey.trim() }));
  }
  function connect() {
    const cfg = getConfig();
    if (!cfg.url || !cfg.anonKey || !window.supabase) return false;
    state.sb = window.supabase.createClient(cfg.url, cfg.anonKey);
    return true;
  }

  function init() {
    if (!connect()) return renderConfig();
    renderLogin();
  }

  function shell(content) {
    $('app').innerHTML = content;
  }

  function renderConfig(error = '') {
    const cfg = getConfig();
    shell(`
      <main class="center-page">
        <section class="login-card setup-card">
          <div class="seal">RUS</div>
          <h1>ตั้งค่าฐานข้อมูลกลาง</h1>
          <p>ใส่ Supabase Project URL และ anon/public key เพื่อให้ทุกเครื่องใช้ข้อมูลเดียวกัน</p>
          ${error ? `<p class="alert">${esc(error)}</p>` : ''}
          <label>Supabase URL</label>
          <input id="cfgUrl" placeholder="https://xxxx.supabase.co" value="${esc(cfg.url || '')}">
          <label>Anon/Public key</label>
          <input id="cfgKey" placeholder="eyJ..." value="${esc(cfg.anonKey || '')}">
          <button class="primary full" id="saveConfigBtn">บันทึกและเชื่อมต่อ</button>
          <details>
            <summary>ยังไม่ได้สร้างตาราง?</summary>
            <p>ให้เปิดไฟล์ <b>supabase/schema-v2.sql</b> ใน repo แล้วนำไปรันใน Supabase SQL Editor ครั้งแรกก่อน</p>
          </details>
        </section>
      </main>`);
    $('saveConfigBtn').onclick = async () => {
      setConfig({ url: $('cfgUrl').value, anonKey: $('cfgKey').value });
      if (!connect()) return renderConfig('ยังเชื่อมต่อไม่ได้ กรุณาตรวจสอบ URL และ key');
      try {
        const { error } = await state.sb.from('profiles').select('id').limit(1);
        if (error) throw error;
        renderLogin();
      } catch (e) {
        renderConfig('เชื่อมต่อ Supabase ได้ แต่ยังไม่พบตาราง กรุณารัน supabase/schema-v2.sql ก่อน');
      }
    };
  }

  function renderLogin() {
    shell(`
      <main class="landing">
        <section class="hero">
          <div class="seal">RUS</div>
          <h1>ระบบออกใบเสร็จรับเงิน</h1>
          <p>มหาวิทยาลัยเทคโนโลยีราชมงคลสุวรรณภูมิ</p>
          <span class="db-ok">ฐานข้อมูลกลาง Supabase</span>
        </section>
        <section class="login-card">
          <div class="tabs">
            <button class="tab active" id="userTab">User</button>
            <button class="tab" id="adminTab">Admin</button>
          </div>
          <form id="userLogin" class="login-form">
            <h2>User Login</h2>
            <label>รหัสผู้ใช้งาน 4 หลัก</label>
            <input id="userCode" maxlength="4" inputmode="numeric" autocomplete="off" placeholder="เช่น 1234">
            <small>เข้าได้เฉพาะรหัสที่ Admin สร้างและเปิดใช้งานเท่านั้น ไม่ต้องใช้ email</small>
            <button class="primary full">เข้าสู่ระบบ</button>
          </form>
          <form id="adminLogin" class="login-form hidden">
            <h2>Admin Login</h2>
            <label>Username</label><input id="adminUser" autocomplete="off" value="admin">
            <label>Password</label><input id="adminPass" type="password">
            <button class="primary full">เข้าสู่ระบบ</button>
          </form>
          <button class="link" id="changeDb">เปลี่ยนฐานข้อมูล</button>
        </section>
      </main>`);

    $('userTab').onclick = () => switchLogin('user');
    $('adminTab').onclick = () => switchLogin('admin');
    $('changeDb').onclick = () => renderConfig();
    $('userLogin').onsubmit = userLogin;
    $('adminLogin').onsubmit = adminLogin;
  }
  function switchLogin(mode) {
    $('userTab').classList.toggle('active', mode === 'user');
    $('adminTab').classList.toggle('active', mode === 'admin');
    $('userLogin').classList.toggle('hidden', mode !== 'user');
    $('adminLogin').classList.toggle('hidden', mode !== 'admin');
  }

  async function userLogin(e) {
    e.preventDefault();
    const code = $('userCode').value.trim();
    if (!/^\d{4}$/.test(code)) return alert('กรุณากรอกรหัส 4 หลัก');
    const { data, error } = await state.sb.rpc('user_login', { p_code: code });
    if (error || !data || !data.ok) return alert((data && data.message) || (error && error.message) || 'เข้าสู่ระบบไม่ได้');
    state.session = { role: 'user', ...data.profile };
    state.view = 'newReceipt';
    await loadAll();
    renderApp();
  }
  async function adminLogin(e) {
    e.preventDefault();
    const { data, error } = await state.sb.rpc('admin_login', { p_username: $('adminUser').value.trim(), p_password: $('adminPass').value });
    if (error || !data || !data.ok) return alert((data && data.message) || (error && error.message) || 'เข้าสู่ระบบไม่ได้');
    state.session = { role: 'admin', ...data.profile };
    state.view = 'dashboard';
    await loadAll();
    subscribeRealtime();
    renderApp();
  }

  async function loadAll() {
    const [u, b, o, bank, r, it] = await Promise.all([
      state.sb.from('profiles').select('*').order('created_at'),
      state.sb.from('receipt_books').select('*').order('created_at'),
      state.sb.from('system_options').select('*').order('sort_order'),
      state.sb.from('bank_accounts').select('*').order('created_at'),
      state.sb.from('receipts').select('*').order('created_at', { ascending: false }).limit(300),
      state.sb.from('receipt_items').select('*').order('created_at')
    ]);
    for (const res of [u, b, o, bank, r, it]) if (res.error) throw res.error;
    state.data.users = u.data || [];
    state.data.books = b.data || [];
    state.data.options = o.data || [];
    state.data.banks = bank.data || [];
    state.data.receipts = r.data || [];
    state.data.items = it.data || [];
  }

  let channel = null;
  function subscribeRealtime() {
    if (channel) return;
    channel = state.sb.channel('rus-realtime')
      .on('postgres_changes', { event: '*', schema: 'public' }, async () => {
        if (!state.session) return;
        await loadAll();
        renderApp(false);
      }).subscribe();
  }

  function renderApp(resetNav = true) {
    const isAdmin = state.session.role === 'admin';
    if (!isAdmin && !['newReceipt'].includes(state.view)) state.view = 'newReceipt';
    shell(`
      <div class="app-shell">
        <aside class="side">
          <h2>RUS Receipt</h2>
          <p><b>${esc(state.session.display_name)}</b><br><span>${state.session.role}${state.session.staff_code ? ' • ' + esc(state.session.staff_code) : ''}</span></p>
          <nav id="nav"></nav>
          <button class="ghost full" id="logoutBtn">ออกจากระบบ</button>
        </aside>
        <main class="main"><div id="view"></div></main>
      </div>
      <div id="printArea"></div>`);
    $('logoutBtn').onclick = () => { state.session = null; renderLogin(); };
    renderNav();
    renderView();
  }
  function renderNav() {
    const menu = state.session.role === 'admin'
      ? [['dashboard','แดชบอร์ด'],['users','ผู้ใช้งาน'],['setup','เมนูระบบ'],['banks','บัญชีธนาคาร'],['books','เล่มที่/เลขที่'],['receipts','ใบเสร็จ'],['reports','รายงาน'],['newReceipt','ออกใบเสร็จ']]
      : [['newReceipt','ออกใบเสร็จ']];
    $('nav').innerHTML = menu.map(([k, t]) => `<button class="nav-btn ${state.view === k ? 'active' : ''}" data-view="${k}">${t}</button>`).join('');
    document.querySelectorAll('.nav-btn').forEach(btn => btn.onclick = () => { state.view = btn.dataset.view; renderApp(); });
  }
  function renderView() {
    const map = { dashboard, users, setup, banks, books, receipts, reports, newReceipt };
    $('view').innerHTML = map[state.view]();
    bindView();
  }

  function dashboard() {
    const normal = state.data.receipts.filter(r => r.status !== 'cancelled');
    const cancelled = state.data.receipts.filter(r => r.status === 'cancelled');
    const net = normal.reduce((s, r) => s + Number(r.total_amount || 0), 0);
    return `<h1>แดชบอร์ด</h1><section class="stats">
      <div><span>ใบเสร็จทั้งหมด</span><b>${state.data.receipts.length}</b></div>
      <div><span>สถานะปกติ</span><b>${normal.length}</b></div>
      <div><span>ยกเลิก</span><b>${cancelled.length}</b></div>
      <div><span>ยอดรับสุทธิ</span><b>${money(net)}</b></div>
    </section><section class="card"><h2>รายการล่าสุด</h2>${receiptTable(state.data.receipts.slice(0, 10))}</section>`;
  }

  function users() {
    const rows = state.data.users.filter(u => u.role === 'user').map(u => `<tr><td>${esc(u.staff_code)}</td><td>${esc(u.display_name)}</td><td>${u.active ? 'ใช้งาน' : 'ปิด'}</td><td class="actions"><button data-user-toggle="${u.id}">${u.active ? 'ปิด' : 'เปิด'}</button><button data-user-edit="${u.id}">แก้ไข</button><button class="danger" data-user-del="${u.id}">ลบ</button></td></tr>`).join('');
    return `<h1>ผู้ใช้งาน</h1><section class="card"><h2>เพิ่ม User</h2><div class="grid3"><label>รหัส 4 หลัก<input id="newUserCode" maxlength="4" inputmode="numeric"></label><label>ชื่อ-นามสกุล<input id="newUserName"></label><button class="primary" id="addUserBtn">เพิ่ม User</button></div><p class="hint">User ใช้รหัส 4 หลักนี้เข้าใช้งานเท่านั้น ไม่ต้องใช้ email</p></section><section class="card table-wrap"><table><thead><tr><th>รหัส</th><th>ชื่อ</th><th>สถานะ</th><th></th></tr></thead><tbody>${rows}</tbody></table></section>`;
  }

  function setup() {
    const cats = [['title','คำนำหน้า'],['payment_item','รายการชำระเงิน'],['project','ชื่อโครงการ'],['payer_bank','ธนาคารผู้ชำระ']];
    return `<h1>เมนูระบบ</h1>${cats.map(([cat, title]) => optionBlock(cat, title)).join('')}`;
  }
  function optionBlock(cat, title) {
    const rows = state.data.options.filter(o => o.category === cat).map(o => `<tr><td>${esc(o.label)}</td><td>${o.active ? 'เปิด' : 'ปิด'}</td><td><button data-opt-toggle="${o.id}">${o.active ? 'ปิด' : 'เปิด'}</button></td></tr>`).join('');
    return `<section class="card"><h2>${title}</h2><div class="inline"><input id="opt-${cat}" placeholder="เพิ่ม${title}"><button data-opt-add="${cat}" class="primary">เพิ่ม</button></div><table><tbody>${rows}</tbody></table></section>`;
  }

  function banks() {
    return `<h1>บัญชีธนาคาร</h1><section class="card"><div class="grid4"><input id="bankName" placeholder="ธนาคาร"><input id="bankAccName" placeholder="ชื่อบัญชี"><input id="bankAccNo" placeholder="เลขบัญชี"><button id="addBankBtn" class="primary">เพิ่มบัญชี</button></div></section><section class="card"><table><tbody>${state.data.banks.map(b => `<tr><td>${esc(b.bank_name)}</td><td>${esc(b.account_name)}</td><td>${esc(b.account_no)}</td><td>${b.active ? 'เปิด' : 'ปิด'}</td><td><button data-bank-toggle="${b.id}">${b.active ? 'ปิด' : 'เปิด'}</button></td></tr>`).join('')}</tbody></table></section>`;
  }

  function books() {
    return `<h1>เล่มที่/เลขที่</h1><section class="card"><div class="grid5"><input id="bookNo" placeholder="เล่มที่"><input id="startNo" type="number" value="1"><input id="endNo" type="number" value="500"><input id="latestNo" type="number" value="0"><button id="addBookBtn" class="primary">เพิ่มเล่ม</button></div><p class="hint">1 เล่มไม่เกิน 500 เลข</p></section><section class="card"><table><thead><tr><th>เล่ม</th><th>ช่วงเลข</th><th>ล่าสุด</th><th>สถานะ</th><th></th></tr></thead><tbody>${state.data.books.map(b => `<tr><td>${esc(b.book_no)}</td><td>${b.start_no}-${b.end_no}</td><td>${b.latest_no}</td><td>${b.active && !b.closed ? 'ใช้งาน' : b.closed ? 'ปิดเล่ม' : 'ไม่ใช้งาน'}</td><td><button data-book-use="${b.id}">ตั้งใช้</button><button data-book-close="${b.id}">${b.closed ? 'เปิดเล่ม' : 'ปิดเล่ม'}</button></td></tr>`).join('')}</tbody></table></section>`;
  }

  function receipts() {
    return `<h1>ใบเสร็จ</h1><section class="card">${receiptTable(state.data.receipts)}</section>`;
  }
  function receiptTable(list) {
    if (!list.length) return '<p class="hint">ยังไม่มีข้อมูล</p>';
    return `<div class="table-wrap"><table><thead><tr><th>วันที่</th><th>เล่ม/เลข</th><th>ผู้ชำระ</th><th>ยอด</th><th>สถานะ</th><th></th></tr></thead><tbody>${list.map(r => `<tr><td>${dt(r.created_at)}</td><td>${esc(r.book_no)}/${String(r.receipt_no).padStart(3,'0')}</td><td>${esc(r.payer_name)}</td><td>${money(r.total_amount)}</td><td><span class="pill ${r.status === 'cancelled' ? 'cancelled' : ''}">${r.status === 'cancelled' ? 'ยกเลิก' : 'ปกติ'}</span></td><td class="actions"><button data-print="${r.id}">พิมพ์สำเนา</button><button class="danger" data-cancel="${r.id}" ${r.status === 'cancelled' ? 'disabled' : ''}>ยกเลิก</button></td></tr>`).join('')}</tbody></table></div>`;
  }

  function reports() {
    const rows = [];
    for (const r of state.data.receipts) {
      for (const it of state.data.items.filter(x => x.receipt_id === r.id)) {
        rows.push({ r, it });
      }
    }
    return `<h1>รายงาน</h1><section class="card"><button class="primary" id="exportCsvBtn">Export CSV</button></section><section class="card table-wrap"><table><thead><tr><th>วันที่</th><th>เวลา</th><th>เล่มที่</th><th>เลขที่</th><th>ผู้ชำระ</th><th>ชื่อโครงการ</th><th>ช่องทาง</th><th>สถานะ</th><th>ผู้ออก</th><th>รายการ</th><th>จำนวนเงิน</th></tr></thead><tbody>${rows.map(({r,it}) => { const d = new Date(r.created_at); return `<tr><td>${d.toLocaleDateString('th-TH')}</td><td>${d.toLocaleTimeString('th-TH')}</td><td>${esc(r.book_no)}</td><td>${String(r.receipt_no).padStart(3,'0')}</td><td>${esc(r.payer_name)}</td><td>${r.project_name === 'ไม่ระบุโครงการ' ? '' : esc(r.project_name || '')}</td><td>${esc(r.payment_method)}</td><td>${r.status === 'cancelled' ? 'ยกเลิก' : 'ปกติ'}</td><td>${esc(r.issuer_name)}</td><td>${esc(it.item_name)}</td><td>${money(it.amount)}</td></tr>`; }).join('')}</tbody></table></section>`;
  }

  function newReceipt() {
    state.receiptLines = state.receiptLines.length ? state.receiptLines : [{ id: uid(), item: option('payment_item')[0] || 'ค่าลงทะเบียน', amount: 0 }];
    const book = state.data.books.find(b => b.active && !b.closed);
    return `<h1>บันทึกรายการชำระเงิน</h1><section class="card"><b>ผู้ออกใบเสร็จ:</b> ${esc(state.session.display_name)} <span class="pill">${book ? 'เล่ม ' + esc(book.book_no) : 'ยังไม่มีเล่มใช้งาน'}</span></section><section class="card"><div class="grid3"><label>ประเภทผู้ชำระ<select id="payerType"><option>บุคคล</option><option>หน่วยงาน</option></select></label><label>คำนำหน้า<select id="payerTitle">${option('title').map(x => `<option>${esc(x)}</option>`).join('')}<option>อื่นๆ</option></select></label><label>คำนำหน้าอื่นๆ<input id="titleOther" placeholder="เช่น พล.ต."></label><label>ชื่อ<input id="firstName"></label><label>นามสกุล<input id="lastName"></label><label>ชื่อหน่วยงาน<input id="orgName"></label><label>รายละเอียด 1<input id="detail1"></label><label>รายละเอียด 2<input id="detail2"></label><label>ช่องทางชำระ<select id="payMethod"><option>เงินสด</option><option>เงินโอน</option></select></label><label>วันที่โอน<input id="transferDate" type="date"></label><label>ธนาคารผู้ชำระ<select id="payerBank">${option('payer_bank').map(x => `<option>${esc(x)}</option>`).join('')}</select></label><label>บัญชีมหาวิทยาลัย<select id="uniBank">${state.data.banks.filter(b=>b.active).map(b => `<option value="${b.id}">${esc(b.bank_name)} ${esc(b.account_no)}</option>`).join('')}</select></label><label>ชื่อโครงการ<select id="projectName">${option('project').map(x => `<option>${esc(x)}</option>`).join('')}</select></label><label>รายละเอียดเพิ่มเติม<input id="moreDetail"></label></div><h2>รายการชำระเงิน</h2><div id="linesBox">${lineRows()}</div><button id="addLineBtn">+ เพิ่มรายการ</button><div class="total">รวม <b id="grandTotal">0.00</b></div><button class="primary full" id="issueBtn">บันทึกแล้วพิมพ์</button></section>`;
  }
  function option(cat) { return state.data.options.filter(o => o.category === cat && o.active).map(o => o.label); }
  function lineRows() {
    return state.receiptLines.map(l => `<div class="line" data-line="${l.id}"><select>${option('payment_item').map(x => `<option ${x===l.item?'selected':''}>${esc(x)}</option>`).join('')}</select><input type="number" step="0.01" value="${Number(l.amount || 0)}"><button class="danger" data-line-del="${l.id}">ลบ</button></div>`).join('');
  }
  function updateLinesFromDom() {
    state.receiptLines = Array.from(document.querySelectorAll('.line')).map(row => ({ id: row.dataset.line, item: row.querySelector('select').value, amount: Number(row.querySelector('input').value || 0) }));
    const total = state.receiptLines.reduce((s,l)=>s+Number(l.amount||0),0);
    const el = $('grandTotal'); if (el) el.textContent = money(total);
  }

  function bindView() {
    document.querySelectorAll('[data-print]').forEach(b => b.onclick = () => printReceipt(b.dataset.print, false));
    document.querySelectorAll('[data-cancel]').forEach(b => b.onclick = () => cancelReceipt(b.dataset.cancel));
    if (state.view === 'users') bindUsers();
    if (state.view === 'setup') bindSetup();
    if (state.view === 'banks') bindBanks();
    if (state.view === 'books') bindBooks();
    if (state.view === 'newReceipt') bindNewReceipt();
    if (state.view === 'reports' && $('exportCsvBtn')) $('exportCsvBtn').onclick = exportCsv;
  }

  function bindUsers() {
    $('addUserBtn').onclick = async () => {
      const code = $('newUserCode').value.trim();
      if (!/^\d{4}$/.test(code)) return alert('รหัสต้องเป็น 4 หลัก');
      const { error } = await state.sb.from('profiles').insert({ role: 'user', staff_code: code, display_name: $('newUserName').value.trim(), active: true });
      if (error) return alert(error.message);
      await loadAll(); renderApp();
    };
    document.querySelectorAll('[data-user-toggle]').forEach(b => b.onclick = async () => { const u = state.data.users.find(x => x.id === b.dataset.userToggle); await state.sb.from('profiles').update({ active: !u.active }).eq('id', u.id); await loadAll(); renderApp(); });
    document.querySelectorAll('[data-user-edit]').forEach(b => b.onclick = async () => { const u = state.data.users.find(x => x.id === b.dataset.userEdit); const name = prompt('ชื่อ-นามสกุล', u.display_name); if (name !== null) { await state.sb.from('profiles').update({ display_name: name }).eq('id', u.id); await loadAll(); renderApp(); }});
    document.querySelectorAll('[data-user-del]').forEach(b => b.onclick = async () => { if (confirm('ลบ User นี้?')) { await state.sb.from('profiles').delete().eq('id', b.dataset.userDel); await loadAll(); renderApp(); }});
  }
  function bindSetup() {
    document.querySelectorAll('[data-opt-add]').forEach(b => b.onclick = async () => { const cat = b.dataset.optAdd; const inp = $('opt-' + cat); if (!inp.value.trim()) return; await state.sb.from('system_options').insert({ category: cat, label: inp.value.trim(), active: true }); await loadAll(); renderApp(); });
    document.querySelectorAll('[data-opt-toggle]').forEach(b => b.onclick = async () => { const o = state.data.options.find(x => x.id === b.dataset.optToggle); await state.sb.from('system_options').update({ active: !o.active }).eq('id', o.id); await loadAll(); renderApp(); });
  }
  function bindBanks() {
    $('addBankBtn').onclick = async () => { await state.sb.from('bank_accounts').insert({ bank_name: $('bankName').value, account_name: $('bankAccName').value, account_no: $('bankAccNo').value, active: true }); await loadAll(); renderApp(); };
    document.querySelectorAll('[data-bank-toggle]').forEach(b => b.onclick = async () => { const row = state.data.banks.find(x => x.id === b.dataset.bankToggle); await state.sb.from('bank_accounts').update({ active: !row.active }).eq('id', row.id); await loadAll(); renderApp(); });
  }
  function bindBooks() {
    $('addBookBtn').onclick = async () => { const start = Number($('startNo').value), end = Number($('endNo').value); if (end < start || end - start + 1 > 500) return alert('1 เล่มไม่เกิน 500 เลข'); await state.sb.from('receipt_books').insert({ book_no: $('bookNo').value, start_no: start, end_no: end, latest_no: Number($('latestNo').value || 0), active: false, closed: false }); await loadAll(); renderApp(); };
    document.querySelectorAll('[data-book-use]').forEach(b => b.onclick = async () => { await state.sb.from('receipt_books').update({ active: false }); await state.sb.from('receipt_books').update({ active: true, closed: false }).eq('id', b.dataset.bookUse); await loadAll(); renderApp(); });
    document.querySelectorAll('[data-book-close]').forEach(b => b.onclick = async () => { const row = state.data.books.find(x => x.id === b.dataset.bookClose); await state.sb.from('receipt_books').update({ closed: !row.closed, active: row.closed ? row.active : false }).eq('id', row.id); await loadAll(); renderApp(); });
  }
  function bindNewReceipt() {
    updateLinesFromDom();
    $('addLineBtn').onclick = () => { updateLinesFromDom(); state.receiptLines.push({ id: uid(), item: option('payment_item')[0] || '', amount: 0 }); $('linesBox').innerHTML = lineRows(); bindNewReceipt(); };
    document.querySelectorAll('.line input,.line select').forEach(el => el.oninput = updateLinesFromDom);
    document.querySelectorAll('[data-line-del]').forEach(b => b.onclick = () => { updateLinesFromDom(); state.receiptLines = state.receiptLines.filter(l => l.id !== b.dataset.lineDel); $('linesBox').innerHTML = lineRows(); bindNewReceipt(); });
    $('issueBtn').onclick = issueReceipt;
  }

  async function issueReceipt() {
    updateLinesFromDom();
    const items = state.receiptLines.filter(l => Number(l.amount) > 0);
    if (!items.length) return alert('กรุณาเพิ่มรายการชำระเงิน');
    const payerType = $('payerType').value;
    const title = $('payerTitle').value === 'อื่นๆ' ? $('titleOther').value.trim() : $('payerTitle').value;
    const payerName = payerType === 'บุคคล' ? [title, $('firstName').value.trim(), $('lastName').value.trim()].filter(Boolean).join(' ') : $('orgName').value.trim();
    if (!payerName) return alert('กรุณากรอกผู้ชำระ');
    const payload = {
      issuer_id: state.session.id,
      issuer_code: state.session.staff_code || 'admin',
      issuer_name: state.session.display_name,
      payer_type: payerType,
      payer_name: payerName,
      detail1: $('detail1').value,
      detail2: $('detail2').value,
      payment_method: $('payMethod').value,
      transfer_date: $('transferDate').value || null,
      payer_bank: $('payerBank').value,
      bank_account_id: $('uniBank').value || null,
      project_name: $('projectName').value,
      more_detail: $('moreDetail').value,
      items
    };
    const { data, error } = await state.sb.rpc('issue_receipt', { p_payload: payload });
    if (error || !data || !data.ok) return alert((data && data.message) || (error && error.message) || 'บันทึกไม่สำเร็จ');
    await loadAll();
    state.receiptLines = [];
    renderApp();
    printReceipt(data.receipt.id, true);
  }
  async function cancelReceipt(id) {
    const reason = prompt('หมายเหตุการยกเลิก');
    if (!reason) return;
    const { data, error } = await state.sb.rpc('cancel_receipt', { p_receipt_id: id, p_reason: reason });
    if (error || !data || !data.ok) return alert((data && data.message) || (error && error.message) || 'ยกเลิกไม่สำเร็จ');
    await loadAll(); renderApp();
  }

  function receiptWithItems(id) {
    const r = state.data.receipts.find(x => x.id === id);
    if (!r) return null;
    return { ...r, items: state.data.items.filter(i => i.receipt_id === id) };
  }
  function printReceipt(id, both) {
    const r = receiptWithItems(id); if (!r) return;
    $('printArea').innerHTML = (both ? receiptPage(r, 'ต้นฉบับ') : '') + receiptPage(r, 'สำเนา');
    setTimeout(() => window.print(), 100);
  }
  function receiptPage(r, label) {
    const project = r.project_name && r.project_name !== 'ไม่ระบุโครงการ' ? `<b>ชื่อโครงการ:</b> ${esc(r.project_name)}<br>` : '';
    return `<section class="receipt-page ${r.status === 'cancelled' ? 'is-cancelled' : ''}"><div class="watermark">RUS</div><div class="receipt-head"><div class="garuda">ครุฑ</div><div class="head-center"><b>มหาวิทยาลัยเทคโนโลยีราชมงคลสุวรรณภูมิ</b><p>ใบเสร็จรับเงิน</p></div><div class="head-meta"><b>${label}</b><br>เล่มที่ ${esc(r.book_no)}<br>เลขที่ ${String(r.receipt_no).padStart(3,'0')}<br>${dt(r.created_at)}</div></div><p><b>ได้รับเงินจาก</b> ${esc(r.payer_name)}<br>${esc(r.detail1 || '')} ${esc(r.detail2 || '')} ${esc(r.more_detail || '')}</p><table class="receipt-table"><tr><th>รายการชำระเงิน</th><th>จำนวนเงิน</th></tr><tr><td class="items-cell">${project}${r.items.map(i => esc(i.item_name)).join('<br>')}</td><td class="amount-cell">${r.items.map(i => money(i.amount)).join('<br>')}</td></tr><tr><td class="center"><b>(${money(r.total_amount)} บาท)</b></td><td class="amount-cell"><b>${money(r.total_amount)}</b></td></tr></table><p class="sign">ไว้เป็นการถูกต้องแล้ว<br><br>(${esc(r.issuer_name)})<br>เจ้าหน้าที่ผู้รับชำระเงิน</p>${r.status === 'cancelled' ? `<div class="cancel-watermark">ยกเลิก</div><p>หมายเหตุ: ${esc(r.cancel_reason || '')}</p>` : ''}</section>`;
  }
  function exportCsv() {
    const rows = [['วันที่','เวลา','เล่มที่','เลขที่','ผู้ชำระ','ชื่อโครงการ','ช่องทาง','สถานะ','ผู้ออก','รายการ','จำนวนเงิน']];
    for (const r of state.data.receipts) for (const it of state.data.items.filter(x => x.receipt_id === r.id)) { const d = new Date(r.created_at); rows.push([d.toLocaleDateString('th-TH'), d.toLocaleTimeString('th-TH'), r.book_no, String(r.receipt_no).padStart(3,'0'), r.payer_name, r.project_name === 'ไม่ระบุโครงการ' ? '' : r.project_name, r.payment_method, r.status === 'cancelled' ? 'ยกเลิก' : 'ปกติ', r.issuer_name, it.item_name, it.amount]); }
    const csv = '\ufeff' + rows.map(r => r.map(x => '"' + String(x ?? '').replace(/"/g, '""') + '"').join(',')).join('\n');
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = 'receipt-report.csv'; a.click();
  }
  return { init };
})();

document.addEventListener('DOMContentLoaded', APP.init);
